<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('admin_model');
        $this->load->helper('url');
        is_logged_in();
    }

    public function index()
    {
 
        $data['title'] = 'Dashboard';
        $data['user'] = $this->db->get_where('user', ['email' =>$this->session->userdata('email')])->row_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/index', $data);
        $this->load->view('templates/footer');
    }


    public function role()
    {
        $data['title'] = 'Role';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['role'] = $this->db->get('user_role')->result_array();
        
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/role', $data);
        $this->load->view('templates/footer');
    }
    
    public function jadwal()
    {
        $data['title'] = 'Penjadwalan Teknisi';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
    
        $data['jadwal'] = $this->db->get('jadwal')->result_array();
        $this->form_validation->set_rules('hari', 'Hari', 'required');
        $this->form_validation->set_rules('jam_mulai', 'Jam Mulai', 'required');
        $this->form_validation->set_rules('jam_akhir', 'Jam Akhir', 'required');
        $this->form_validation->set_rules('lokasi', 'Lokasi', 'required');
        $this->form_validation->set_rules('kegiatan', 'Kegiatan', 'required');
        $this->form_validation->set_rules('teknisi', 'Teknisi', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/jadwal', $data);
            $this->load->view('templates/footer');
        } else {
            $data = array(
                'hari' => $this->input->post('hari'),
                'jam_mulai' => $this->input->post('jam_mulai'),
                'jam_akhir' => $this->input->post('jam_akhir'),
                'lokasi' => $this->input->post('lokasi'),
                'kegiatan' => $this->input->post('kegiatan'),
                'name' => $this->input->post('teknisi')
            );
            $this->db->insert('jadwal', $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Jadwal berhasil ditambahkan</div>');
            redirect('admin/jadwal');
            
        }
    }
    
    
    public function edit($id)
    {
        //memanggil  model
        $where = array('id' => $id);
        $data['title'] = 'Edit Jadwal';
    
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['jadwal'] = $this->db->get('jadwal')->result_array();
        $data['user_jadwal'] = $this->admin_model->editJadwal($where, 'jadwal')->result();
        // $this->load->model('admin_model');
        // $data = array(
        //     "jadwal" => $this->admin_model->edit($id));
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/editjadwal', $data);
        $this->load->view('templates/footer');

        if ($this->input->method() == "post") {
            $insert = $this->admin_model->update(array(
                'hari' => $this->input->post('hari'),
                'jam_mulai' => $this->input->post('jam_mulai'),
                'jam_akhir' => $this->input->post('jam_akhir'),
                'lokasi' => $this->input->post('lokasi'),
                'kegiatan' => $this->input->post('kegiatan'),
                'name' => $this->input->post('teknisi')
            ), $id);
        }
    }
    public function hapusjadwal($id)
    {
        $this->load->model('admin_model');
        $hapus=$this->admin_model->gethapus($id);
        if ($hapus) {
            echo "<script>alert('Sukses dihapus')</script>";
            redirect(base_url() . 'admin/jadwal', 'refresh');
        } else {
            echo "<script>alert('Gagal dihapus')</script>";
            redirect(base_url() . 'admin/jadwal', 'refresh');
        }
    }


    public function roleAccess($role_id)
    {
        $data['title'] = 'Role Access';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['role'] = $this->db->get_where('user_role', ['id' => $role_id])->row_array();

        $this->db->where('id !=', 1);
        $data['menu'] = $this ->db->get('user_menu')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/role-access', $data);
        $this->load->view('templates/footer');
    }


    public function changeAccess()
    {
        $menu_id = $this->input->post('menuId');
        $role_id = $this->input->post('roleId');

        $data = [
            'role_id' => $role_id,
            'menu_id' => $menu_id
        ];

        $result = $this->db->get_where('user_access_menu', $data);

        if($result->num_rows() < 1) {
            $this->db->insert('user_access_menu', $data);
        } else{
            $this->db->delete('user_access_menu', $data);
        }

        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Akses Diubah</div>');
    }
}
