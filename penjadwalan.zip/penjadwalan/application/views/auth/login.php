<div class="container">
    <div class="card card-login mx-auto mt-5">
        <div class="card-header">Login</div>
        <?= $this->session->flashdata('message'); ?>
        <div class="card-body">
            <form method="post" action="<?= base_url('auth'); ?>">
                <div class="form-group">
                    <div class="form-label-group"></div>
                        <input type="text" id="email" name="email" class="form-control" placeholder="Alamat email" required="required" autofocus="autofocus">
                        <label for="inputEmail" value="<?= set_value('email'); ?>"></label>
                        <?= form_error('email', '<small class="text-danger pl-3">', '</small>'); ?>

                </div>
                <div class="form-group">
                    <div class="form-label-group"></div>
                        <input type="password" id="password" name="password" class="form-control" placeholder="Kata Sandi" required="required">
                        <label for="inputPassword"></label>
                        <?= form_error('password', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>
                <div class="form-group">
                    <div class="checkbox">
                        <label>
                            <input type="checkbox" value="remember-me">
                            Ingat Kata Sandi
                        </label>
                    </div>
                </div>
                <button class="btn btn-primary btn-block" type="submit">Login</button>
            </form>
            <div class="text-center">
                <a class="d-block small mt-3" href="<?= base_url('auth/registration'); ?> ">Registrasi Akun</a>
            </div>
        </div>
    </div>
</div>