<div class="container">
    <div class="card card-register mx-auto mt-5">
        <div class="card-header">Registrasi Akun</div>
        <div class="card-body">
            <form class="user" method="post" action="<?= base_url('auth/registration'); ?>">
                <div class="form-group">
                    <div class="form-row">
                        <div class="col-md">
                            <div class="form-group">
                                <div class="form-label-group"></div>
                                <input type="text" id="name" name="name" class="form-control" placeholder="Nama" value="<?= set_value('name'); ?>" required="required">
                                <label for="inputName"></label>

                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="form-label-group"></div>
                        <input type="text" id="email" name="email" class="form-control" placeholder="Alamat email" value="<?= set_value('email'); ?>" required="required">
                        <?= form_error('email', '<small class="text-danger pl-3">', '</small>'); ?>
                        <label for="inputEmail"></label>

                    </div>
                    <div class="form-group">
                        <div class="form-row">
                            <div class="col-md-6">
                                <div class="form-label-group"></div>
                                <input type="password" id="password1" name="password1" class="form-control" placeholder="Kata sandi" required="required">
                                <?= form_error('password1', '<small class="text-danger pl-3">', '</small>'); ?>
                                <label for="inputPassword"></label>

                            </div>
                            <div class="col-md-6">
                                <div class="form-label-group"></div>
                                <input type="password" id="password2" name="password2" class="form-control" placeholder="Konfirmasi kata sandi" required="required">
                                <label for="confirmPassword"></label>

                            </div>
                        </div>
                    </div>
                    <button class="btn btn-primary btn-block" type="submit">Register</button>
            </form>
            <div class="text-center">
                <a class="d-block small mt-3" href="<?= base_url(); ?>auth">Halaman Login</a>
            </div>
        </div>
    </div>
</div>