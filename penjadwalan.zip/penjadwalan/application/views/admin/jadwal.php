<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>



    <div class="row">
        <div class="col-lg">
            <?php if (validation_errors()) : ?>
                <div class="alert alert-danger" role="alert">
                    <?= validation_errors(); ?>
                </div>
            <?php endif; ?>

            <?= $this->session->flashdata('message'); ?>
            <a href="" class="btn btn-primary mb-3" data-toggle="modal" data-target="#newMenuModal">Tambahkan Jadwal</a>
            <div class="modal fade" id="newMenuModal" tabindex="-1" role="dialog" aria-labelledby="newMenuModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="newMenuModalLabel">Tambahkan Jadwal</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form action="<?= base_url('admin/jadwal'); ?>" method="post">
                            <div class="modal-body">
                                <div class="form-group">
                                    <select name="hari" id="hari" class="form-control">
                                        <option value="">Hari</option>
                                        <option value="Senin">Senin</option>
                                        <option value="Selasa">Selasa</option>
                                        <option value="Rabu">Rabu</option>
                                        <option value="Kamis">Kamis</option>
                                        <option value="Jumat">Jumat</option>
                                        <option value="Sabtu">Sabtu</option>
                                        <option value="Minggu">Minggu</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" id="jam_mulai" name="jam_mulai" placeholder="Jam Mulai">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" id="jam_akhir" name="jam_akhir" placeholder="Jam Akhir">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" id="lokasi" name="lokasi" placeholder="Lokasi">
                                </div>
                                <div class="form-group">
                                    <select name="kegiatan" id="kegiatan" class="form-control">
                                        <option value="">Kegiatan</option>
                                        <option value="Maintenance">Maintenance</option>
                                        <option value="Survey">Survey</option>
                                        <option value="Dismantle">Dismantle</option>
                                        <option value="Troubleshooting">Troubleshooting</option>
                                        <option value="Instalasi">Instalasi</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" id="name" name="teknisi" placeholder="Teknisi">
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Add</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <table class=" table table-bordered">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Hari</th>
                        <th scope="col">Jam</th>
                        <th scope="col">Lokasi</th>
                        <th scope="col">Kegiatan</th>
                        <th scope="col">Teknisi</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <?php $no = 1;
                foreach ($jadwal as $jadwals) { ?>
                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td><?php echo $jadwals['hari']; ?></td>
                        <td><?php echo $jadwals['jam_mulai']; ?> - <?php echo $jadwals['jam_akhir']; ?></td>
                        <td><?php echo $jadwals['lokasi']; ?></td>
                        <td><?php echo $jadwals['kegiatan']; ?></td>
                        <td><?php echo $jadwals['name']; ?></td>
                        <td>
                            <a href="<?php echo base_url() ?>Admin/edit/<?php echo $jadwals['id']; ?>" class="badge badge-success">Edit</a>
                            <a href="<?php echo base_url() ?>Admin/hapusjadwal/<?php echo $jadwals['id']; ?>" onclick="return confirm('Hapus data ini?')" class="badge badge-danger">Hapus</a>
                        </td>
                    </tr>
                <?php } ?>
            </table>
        </div>
    </div>
</div>
</div>
<!--/.col-xs-6.col-lg-4-->