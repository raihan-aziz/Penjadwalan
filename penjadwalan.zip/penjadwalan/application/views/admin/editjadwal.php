<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>



    <div class="row">
        <div class="col-lg">
            <?php if (validation_errors()) : ?>
                <div class="alert alert-danger" role="alert">
                    <?= validation_errors(); ?>
                </div>
            <?php endif; ?>

        <?php $this->load->helper('url'); ?><td></td>
        <a href=<?php echo base_url() . "admin/jadwal"; ?> class="btn btn-primary mb-3">Kembali</a></h3>
        <div id="body">
            <form method="post">
                <table>
                    <tr>
                        <td><label>Hari</label></td>
                        <td><select name="hari" class="form-control" value="<?php echo $user_jadwal[0]->hari; ?>">
                                <option value="">Hari</option>
                                <option value="Senin">Senin</option>
                                <option value="Selasa">Selasa</option>
                                <option value="Rabu">Rabu</option>
                                <option value="Kamis">Kamis</option>
                                <option value="Jumat">Jumat</option>
                                <option value="Sabtu">Sabtu</option>
                                <option value="Minggu">Minggu</option>
                            </select></td>
                    </tr>
                    <tr>
                        <td><label>Jam Mulai</label></td>
                        <td><input type="text" name="jam_mulai" class="form-control" value="<?php echo $user_jadwal[0]->jam_mulai; ?>"></td>
                    </tr>
                    <tr>
                        <td><label>Jam Akhir</label></td>
                        <td><input type="text" name="jam_akhir" class="form-control" value="<?php echo $user_jadwal[0]->jam_akhir; ?>"></td>
                    </tr>
                    <tr>
                        <td><label>Lokasi</label></td>
                        <td><input type="text" name="lokasi" class="form-control" value="<?php echo $user_jadwal[0]->lokasi; ?>"></td>
                    </tr>
                    <tr>
                        <td><label>Kegiatan</label></td>
                        <td><select name="kegiatan" class="form-control" value="<?php echo $user_jadwal[0]->kegiatan; ?>">
                                <option value="">Kegiatan</option>
                                <option value="Maintenance">Maintenance</option>
                                <option value="Survey">Survey</option>
                                <option value="Dismantle">Dismantle</option>
                                <option value="Troubleshooting">Troubleshooting</option>
                                <option value="Instalasi">Instalasi</option>
                            </select></td>
                    </tr>
                    <tr>
                        <td><label>Teknisi</label></td>
                        <td><input type="text" name="teknisi" class="form-control" value="<?php echo $user_jadwal[0]->name; ?>"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td colspan="2"><button type="submit">Simpan</button></td>
                    </tr>
                </table>

            </form>
        </div>
    </div>
    </div>
</div>
</div>

</body>

</html>