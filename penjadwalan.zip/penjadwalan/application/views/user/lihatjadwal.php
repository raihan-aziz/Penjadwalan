<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>
            <table class=" table table-bordered">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Hari</th>
                        <th scope="col">Jam</th>
                        <th scope="col">Lokasi</th>
                        <th scope="col">Kegiatan</th>
                        <th scope="col">Teknisi</th>
                    </tr>
                </thead>
                <?php $no = 1;
                foreach ($jadwal as $jadwals) {
                    if ($jadwals['name'] == $user['name']) { ?>
                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td><?php echo $jadwals['hari']; ?></td>
                        <td><?php echo $jadwals['jam_mulai']; ?> - <?php echo $jadwals['jam_akhir']; ?></td>
                        <td><?php echo $jadwals['lokasi']; ?></td>
                        <td><?php echo $jadwals['kegiatan']; ?></td>
                        <td><?php echo $jadwals['name'];
                        ?></td>
                    </tr>
                <?php 
                        }
                    } 
                ?>
            </table>
        </div>
    </div>

<!--/.col-xs-6.col-lg-4-->