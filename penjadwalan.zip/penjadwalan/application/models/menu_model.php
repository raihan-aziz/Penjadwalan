<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Menu_model extends CI_Model
{
    public function getSubMenu()
    {
        $query = "SELECT `user_sub_menu`.*, `user_menu`.`menu`
                  FROM `user_sub_menu` JOIN `user_menu`
                  ON `user_sub_menu`.`menu_id` = `user_menu`.`id`
                ";
        return $this->db->query($query)->result_array();
    }
    public function hapusSubmenu($id)
    {
        return $this->db->get('user_sub_menu');
    }
    function getdelete($id)
    {
        $this->load->database();
        //berdasarkan berdasarkan id
        $this->db->where("id", $id);
        //mengembalikan nilai
        return $this->db->delete('user_sub_menu');
    }
    public function hapusmenu($id)
    {
        return $this->db->get('user_menu');
    }
    function gethapus($id)
    {
        $this->load->database();
        //berdasarkan berdasarkan id
        $this->db->where("id", $id);
        //mengembalikan nilai
        return $this->db->delete('user_menu');
    }
  
}