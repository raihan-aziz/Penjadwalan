<?php
class admin_model extends CI_Model{
    public function get(){
        $this->load->database();
        $this->db->select("*");
        $query = $this->db->get('jadwal');
        return $query->result();
    
}

function editJadwal($id,$table){
    return $this->db->get_where($table, $id);
}


public function hapusjadwal($id)
{
    return $this->db->get('jadwal'); 
}
    function gethapus($id)
    {
        $this->load->database();
        //berdasarkan berdasarkan id
        $this->db->where("id", $id);
        //mengembalikan nilai
        return $this->db->delete('jadwal');
    
}
public function edit($id)
{
    //memanggil database
    $this->load->database();
    //berdasarkan berdasarkan id
    $this->db->where("id", $id);
    //ambil data pegawai
    $query = $this->db->get('jadwal');
    //mengembalikan nilai
    return $query->result();
}
    public function update($data = array(), $id)
    {
        //memanggil database
        $this->load->database();
        //berdasarkan berdasarkan id
        $this->db->where("id", $id);
        //mengembalikan nilai
        return $this->db->update('jadwal', $data);
    }
}